package com.example.fooddeliveryapp2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
